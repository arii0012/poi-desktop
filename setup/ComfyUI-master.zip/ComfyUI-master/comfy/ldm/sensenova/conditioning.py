import torch


IMAGE_CONTEXT_ID = 151669
IMAGE_START_ID = 151670
IMAGE_END_ID = 151671
IM_START_ID = 151644
IM_END_ID = 151645
THINK_START_ID = 151667
THINK_END_ID = 151668
THINK_SUFFIX_IDS = (271, IMAGE_START_ID)
USER_ID = 872
ASSISTANT_ID = 77091
NEWLINE_ID = 198
IMAGE_LABEL_ID = 1906
HYPHEN_ID = 12
DIGIT_ZERO_ID = 15
COLON_ID = 25
MERGED_PATCH_SIZE = 32


def preprocess_reference(image):
    if image.ndim == 3:
        image = image.unsqueeze(0)
    image = image[:, :, :, :3].movedim(-1, 1).float()
    if image.shape[1] == 0:
        image = image.new_zeros((image.shape[0], 3, *image.shape[-2:]))
    elif image.shape[1] < 3:
        repeats = (3 + image.shape[1] - 1) // image.shape[1]
        image = image.repeat(1, repeats, 1, 1)[:, :3]
    mean = image.new_tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1)
    std = image.new_tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1)
    return (image - mean) / std


def split_reference_batches(images):
    references = []
    for image in images:
        if image.ndim == 3:
            image = image.unsqueeze(0)
        references.extend(image[index : index + 1] for index in range(image.shape[0]))
    return references


def preprocess_references(images):
    return [preprocess_reference(image) for image in split_reference_batches(images)]


def reference_grid(height, width, patch_size):
    return (
        max(1, (height + patch_size - 1) // patch_size),
        max(1, (width + patch_size - 1) // patch_size),
    )


def image_token_mask(input_ids):
    # Image-control IDs generated outside an image block remain text embeddings.
    positions = torch.arange(input_ids.shape[-1], device=input_ids.device)
    starts = torch.where(input_ids == IMAGE_START_ID, positions, -1).cummax(dim=-1).values
    ends = torch.where(input_ids == IMAGE_END_ID, positions, -1).cummax(dim=-1).values
    return (input_ids == IMAGE_CONTEXT_ID) & (starts > ends)


def prepare_prefix_inputs(
    input_ids, reference_images, patch_size, dtype, *,
    image_only=False, expand_images=True, generated_start=None,
):
    reference_images = preprocess_references(reference_images) if reference_images else []
    reference_grids = [
        reference_grid(image.shape[-2], image.shape[-1], patch_size)
        for image in reference_images
    ]
    if reference_images and expand_images:
        input_ids = condition_input_ids(input_ids, reference_grids, image_only=image_only)
    values = input_ids[0].tolist()
    image_slots = []
    in_image = False
    for token in values:
        if token == IMAGE_START_ID:
            in_image = True
        elif token == IMAGE_END_ID:
            in_image = False
        image_slots.append(token == IMAGE_CONTEXT_ID and in_image)
    text_start = len(values) if generated_start is None else generated_start
    expected_slots = sum(height * width for height, width in reference_grids)
    actual_slots = sum(
        token == IMAGE_CONTEXT_ID and (index < text_start or image_slots[index])
        for index, token in enumerate(values)
    )
    if actual_slots != expected_slots:
        raise ValueError(
            f"SenseNova prefix has {actual_slots} image context tokens, "
            f"but reference images require {expected_slots}."
        )
    starts = [index for index, token in enumerate(values) if token == IMAGE_START_ID]
    ends = [
        index for index, token in enumerate(values)
        if token == IMAGE_END_ID and (index < text_start or (index > 0 and image_slots[index - 1]))
    ]
    if starts and starts[-1] == len(values) - 1:
        starts.pop()
    if len(starts) != len(reference_grids) or len(ends) != len(reference_grids):
        raise ValueError("SenseNova prefix image blocks do not match its reference images.")
    for index, (start, end, (height, width)) in enumerate(zip(starts, ends, reference_grids), 1):
        if values[start + 1:end] != [IMAGE_CONTEXT_ID] * (height * width):
            raise ValueError(
                f"SenseNova prefix image block {index}: reference images "
                f"require {height * width} contiguous image context tokens."
            )
    if not reference_images:
        return input_ids, None, None, None
    indexes = thw_indexes(input_ids, reference_grids)
    return input_ids, reference_images, indexes, block_causal_mask(indexes, dtype=dtype)


def _image_tokens(token_height, token_width):
    return (
        [IMAGE_START_ID]
        + [IMAGE_CONTEXT_ID] * (token_height * token_width)
        + [IMAGE_END_ID]
    )


def expand_interleave_inputs(input_ids, reference_images, image_only):
    references = split_reference_batches(reference_images or [])
    if references:
        reference_grids = [
            reference_grid(image.shape[-3], image.shape[-2], MERGED_PATCH_SIZE)
            for image in references
        ]
        input_ids = condition_input_ids(input_ids, reference_grids, image_only=image_only, append_image_start=False, image_labels=False)
    return input_ids, references


def prepare_interleave_image(latent_samples):
    if latent_samples.ndim != 4 or latent_samples.shape[0] != 1:
        raise ValueError("SenseNova interleave requires one BCHW latent image per stage.")
    if latent_samples.shape[1] != 3:
        raise ValueError("SenseNova interleave requires a three-channel RGB pixel latent from KSampler.")

    image = (latent_samples * 0.5 + 0.5).movedim(1, -1)
    token_height, token_width = reference_grid(*latent_samples.shape[-2:], MERGED_PATCH_SIZE)
    return [IMAGE_CONTEXT_ID] * (token_height * token_width) + [IMAGE_END_ID], image


def _image_label_tokens(index):
    digits = (DIGIT_ZERO_ID + int(digit) for digit in str(index + 1))
    return (IMAGE_LABEL_ID, HYPHEN_ID, *digits, COLON_ID)


def condition_input_ids(
    input_ids, reference_grids, image_only=False, append_image_start=True, image_labels=True
):
    image_blocks = [_image_tokens(height, width) for height, width in reference_grids]
    if image_only:
        values = (
            [IM_START_ID, USER_ID, NEWLINE_ID]
            + [token for block in image_blocks for token in block]
            + [
                IM_END_ID,
                NEWLINE_ID,
                IM_START_ID,
                ASSISTANT_ID,
                NEWLINE_ID,
            ]
            + ([IMAGE_START_ID] if append_image_start else [])
        )
        return torch.tensor([values], dtype=torch.long, device=input_ids.device)

    values = input_ids[0].tolist()
    starts = [index for index, value in enumerate(values) if value == IM_START_ID]
    insert_at = starts[1] + 3 if len(starts) > 1 else len(values)
    inserted = []
    for index, block in enumerate(image_blocks):
        if image_labels and len(image_blocks) > 1:
            inserted.extend(_image_label_tokens(index))
        inserted.extend(block)
        inserted.append(NEWLINE_ID)
    values[insert_at:insert_at] = inserted
    return torch.tensor([values], dtype=torch.long, device=input_ids.device)


def thw_indexes(input_ids, reference_grids):
    values = input_ids[0]
    image_start_shift = torch.cat(
        (
            torch.zeros(1, dtype=torch.long, device=values.device),
            (values == IMAGE_START_ID).long(),
        )
    )[:-1]
    selected = image_token_mask(input_ids)[0]
    not_image = (~selected).long()
    time_indexes = (image_start_shift + not_image).cumsum(0) - 1
    height_indexes = torch.zeros_like(time_indexes)
    width_indexes = torch.zeros_like(time_indexes)
    height_positions = []
    width_positions = []
    for token_height, token_width in reference_grids:
        positions = torch.arange(
            token_height * token_width, dtype=torch.long, device=values.device
        )
        height_positions.append(positions // token_width)
        width_positions.append(positions % token_width)
    if height_positions:
        height_indexes[selected] = torch.cat(height_positions)
        width_indexes[selected] = torch.cat(width_positions)
    return torch.stack((time_indexes, height_indexes, width_indexes)).unsqueeze(0)


def block_causal_mask(time_indexes, dtype=torch.float32):
    values = time_indexes[0, 0]
    length = values.shape[0]
    same_block = values[:, None] == values[None, :]
    positions = torch.arange(length, device=values.device)
    causal = positions[None, :] <= positions[:, None]
    allowed = same_block | causal
    mask = torch.zeros((1, 1, length, length), dtype=dtype, device=values.device)
    return mask.masked_fill_(~allowed[None, None], float("-inf"))
